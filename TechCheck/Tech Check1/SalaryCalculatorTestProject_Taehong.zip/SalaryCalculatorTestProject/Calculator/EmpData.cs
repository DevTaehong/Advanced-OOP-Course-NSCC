﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    public class EmpData
    {
        public double TaxAmount { set; get; }
        public double DependentDeduction { set; get; }
        public double NetTaxAmount { set; get; }
        public double TotalTakeHome { set; get; }
    }

    //W0445964 Taehong
}
